'use client'

import { FormEvent, useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { AnimatePresence, motion } from 'framer-motion'
import { ChevronRight, ImagePlus, Loader2, Lock, Send, Sparkles, X } from 'lucide-react'
import { browserClient } from '@/lib/supabase-browser'
import {
  BUCKET,
  CREATOR_NAME,
  IMAGE_EXT,
  MAX_BODY_CHARS,
  MAX_IMAGE_BYTES,
  MAX_IMAGES,
  MAX_NICK_CHARS,
} from '@/lib/constants'
import { timeAgo } from '@/lib/utils'

type Pick = { id: string; file: File; url: string }
type Saved = { token: string; nickname: string; createdAt: string }

const STORE = 'fan-inbox:threads'

export default function SubmitPage() {
  const router = useRouter()
  const fileRef = useRef<HTMLInputElement>(null)
  const [nickname, setNickname] = useState('')
  const [body, setBody] = useState('')
  const [website, setWebsite] = useState('') // honeypot
  const [picks, setPicks] = useState<Pick[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [saved, setSaved] = useState<Saved[]>([])

  // Revoke preview URLs on unmount
  const picksRef = useRef(picks)
  picksRef.current = picks
  useEffect(() => () => picksRef.current.forEach((p) => URL.revokeObjectURL(p.url)), [])

  // Threads this device has already started (kept only in this browser)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORE)
      if (raw) setSaved(JSON.parse(raw) as Saved[])
    } catch {}
  }, [])

  function addFiles(list: FileList | null) {
    if (!list) return
    setError(null)
    const next = [...picks]
    for (const f of Array.from(list)) {
      if (next.length >= MAX_IMAGES) {
        setError(`You can attach up to ${MAX_IMAGES} images.`)
        break
      }
      if (!(f.type in IMAGE_EXT)) {
        setError('Only JPG, PNG, WebP, GIF or HEIC images are supported.')
        continue
      }
      if (f.size > MAX_IMAGE_BYTES) {
        setError('Each image must be under 8 MB.')
        continue
      }
      next.push({ id: Math.random().toString(36).slice(2), file: f, url: URL.createObjectURL(f) })
    }
    setPicks(next)
    if (fileRef.current) fileRef.current.value = ''
  }

  function removePick(id: string) {
    setPicks((prev) => {
      const gone = prev.find((p) => p.id === id)
      if (gone) URL.revokeObjectURL(gone.url)
      return prev.filter((p) => p.id !== id)
    })
  }

  async function submit(e: FormEvent) {
    e.preventDefault()
    if (busy || (!body.trim() && picks.length === 0)) return
    setBusy(true)
    setError(null)

    try {
      let imagePaths: string[] = []

      if (picks.length) {
        const r = await fetch('/api/upload-url', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ types: picks.map((p) => p.file.type) }),
        })
        const j = await r.json().catch(() => null)
        if (!r.ok) throw new Error(j?.error ?? 'Upload failed. Please try again.')

        const uploads = j.uploads as { path: string; token: string }[]
        const sb = browserClient()
        await Promise.all(
          uploads.map(async (u, i) => {
            const { error: upErr } = await sb.storage
              .from(BUCKET)
              .uploadToSignedUrl(u.path, u.token, picks[i].file, { contentType: picks[i].file.type })
            if (upErr) throw new Error(upErr.message)
          }),
        )
        imagePaths = uploads.map((u) => u.path)
      }

      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nickname, body, imagePaths, website }),
      })
      const data = await res.json().catch(() => null)
      if (!res.ok) throw new Error(data?.error ?? 'Could not send your message.')

      try {
        const entry: Saved = {
          token: data.token,
          nickname: nickname.trim() || 'Anonymous',
          createdAt: new Date().toISOString(),
        }
        const prev = JSON.parse(localStorage.getItem(STORE) || '[]') as Saved[]
        localStorage.setItem(STORE, JSON.stringify([entry, ...prev].slice(0, 20)))
      } catch {}

      router.push(`/t/${data.token}`)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.')
      setBusy(false)
    }
  }

  const canSend = !busy && (body.trim().length > 0 || picks.length > 0)

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-md flex-col px-4 pb-10 pt-[max(2.5rem,env(safe-area-inset-top))] sm:max-w-lg sm:justify-center">
      <motion.header
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        className="mb-6 text-center"
      >
        <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-[1.4rem] bg-gradient-to-br from-sky-400 to-indigo-500 text-white shadow-lg shadow-indigo-500/30">
          <Sparkles className="h-8 w-8" />
        </div>
        <h1 className="text-[32px] font-bold leading-tight tracking-tight">Message {CREATOR_NAME}</h1>
        <p className="mt-2 text-[15px] text-zinc-600 dark:text-zinc-400">
          Private, just between us. Add a photo if you like — replies show up on your tracking page.
        </p>
      </motion.header>

      <motion.form
        onSubmit={submit}
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
        className="glass space-y-3 rounded-3xl p-4 sm:p-5"
      >
        <input
          className="field"
          placeholder="Nickname (optional)"
          maxLength={MAX_NICK_CHARS}
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          autoComplete="off"
        />

        <div className="relative">
          <textarea
            className="field min-h-[9rem] resize-none"
            placeholder="Write your message…"
            maxLength={MAX_BODY_CHARS}
            value={body}
            onChange={(e) => setBody(e.target.value)}
          />
          {body.length > MAX_BODY_CHARS - 300 && (
            <span className="absolute bottom-3 right-4 text-xs tabular-nums text-zinc-400">
              {body.length}/{MAX_BODY_CHARS}
            </span>
          )}
        </div>

        {/* Honeypot — hidden from people, bots fill it in */}
        <input
          tabIndex={-1}
          aria-hidden
          autoComplete="off"
          name="website"
          value={website}
          onChange={(e) => setWebsite(e.target.value)}
          className="absolute left-[-9999px] h-0 w-0 opacity-0"
        />

        {/* Image previews */}
        <div className="flex flex-wrap gap-2.5">
          <AnimatePresence initial={false}>
            {picks.map((p) => (
              <motion.div
                key={p.id}
                layout
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ type: 'spring', damping: 24, stiffness: 320 }}
                className="relative h-[76px] w-[76px] overflow-hidden rounded-2xl shadow-soft ring-1 ring-black/5"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={p.url} alt="Selected image preview" className="h-full w-full object-cover" />
                <button
                  type="button"
                  aria-label="Remove image"
                  onClick={() => removePick(p.id)}
                  className="absolute right-1 top-1 grid h-6 w-6 place-items-center rounded-full bg-black/55 text-white backdrop-blur transition active:scale-90"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>

          {picks.length < MAX_IMAGES && (
            <motion.button
              layout
              type="button"
              onClick={() => fileRef.current?.click()}
              className="grid h-[76px] w-[76px] place-items-center rounded-2xl border-2 border-dashed border-sky-400/50 bg-sky-400/10 text-sky-600 transition active:scale-95 dark:text-sky-300"
              aria-label="Add image"
            >
              <ImagePlus className="h-6 w-6" />
            </motion.button>
          )}
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif,image/heic,image/heif"
            multiple
            hidden
            onChange={(e) => addFiles(e.target.files)}
          />
        </div>

        <AnimatePresence>
          {error && (
            <motion.p
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="rounded-2xl bg-red-500/10 px-4 py-2.5 text-sm font-medium text-red-600 dark:text-red-400"
            >
              {error}
            </motion.p>
          )}
        </AnimatePresence>

        <button type="submit" disabled={!canSend} className="btn-primary w-full">
          {busy ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" /> Sending…
            </>
          ) : (
            <>
              <Send className="h-5 w-5" /> Send privately
            </>
          )}
        </button>

        <p className="flex items-center justify-center gap-1.5 pt-1 text-xs text-zinc-500">
          <Lock className="h-3.5 w-3.5" /> No account needed. Only you and {CREATOR_NAME} can see this.
        </p>
      </motion.form>

      {saved.length > 0 && (
        <motion.section
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-6"
        >
          <h2 className="mb-2 px-2 text-[13px] font-semibold uppercase tracking-wide text-zinc-500">
            Your messages on this device
          </h2>
          <ul className="glass divide-y divide-black/5 overflow-hidden rounded-3xl dark:divide-white/10">
            {saved.map((s) => (
              <li key={s.token}>
                <Link
                  href={`/t/${s.token}`}
                  className="flex items-center justify-between gap-3 px-4 py-3.5 transition active:bg-black/5 dark:active:bg-white/10"
                >
                  <div className="min-w-0">
                    <p className="truncate text-[16px] font-semibold">{s.nickname}</p>
                    <p className="text-sm text-zinc-500">Sent {timeAgo(s.createdAt)}</p>
                  </div>
                  <ChevronRight className="h-5 w-5 shrink-0 text-zinc-400" />
                </Link>
              </li>
            ))}
          </ul>
        </motion.section>
      )}
    </main>
  )
}
