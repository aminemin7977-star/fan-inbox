import { redirect } from 'next/navigation'
import { isAdmin } from '@/lib/auth'
import Dashboard from '@/components/Dashboard'

export const dynamic = 'force-dynamic'

export default async function AdminPage() {
  // Server-side gate: unauthenticated visitors never receive the dashboard.
  if (!(await isAdmin())) redirect('/admin/login')
  return <Dashboard />
}
