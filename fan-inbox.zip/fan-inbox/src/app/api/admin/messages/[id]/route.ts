import { isAdmin } from '@/lib/auth'
import { admin } from '@/lib/supabase-admin'
import { fetchOne } from '@/lib/messages'
import { BUCKET } from '@/lib/constants'
import { err, json, UUID_RE } from '@/lib/http'

export const dynamic = 'force-dynamic'

type Ctx = { params: Promise<{ id: string }> }

/** Mark read / unread, archive / unarchive. */
export async function PATCH(req: Request, ctx: Ctx) {
  if (!(await isAdmin())) return err('Unauthorized', 401)
  const { id } = await ctx.params
  if (!UUID_RE.test(id)) return err('Invalid id')

  const b = (await req.json().catch(() => null)) as { status?: unknown; archived?: unknown } | null
  if (!b) return err('Invalid request.')

  const sb = admin()
  const { data: cur } = await sb.from('messages').select('status').eq('id', id).maybeSingle()
  if (!cur) return err('Not found', 404)

  const patch: Record<string, unknown> = {}
  if (b.status === 'read' && cur.status === 'received') {
    patch.status = 'read'
    patch.read_at = new Date().toISOString()
  }
  if (b.status === 'received' && cur.status === 'read') {
    patch.status = 'received'
    patch.read_at = null
  }
  if (typeof b.archived === 'boolean') patch.archived = b.archived

  if (Object.keys(patch).length) {
    const { error } = await sb.from('messages').update(patch).eq('id', id)
    if (error) return err('Server error', 500)
  }
  return json({ message: await fetchOne(id) })
}

/** Permanently delete a message, its replies (cascade) and its images. */
export async function DELETE(_req: Request, ctx: Ctx) {
  if (!(await isAdmin())) return err('Unauthorized', 401)
  const { id } = await ctx.params
  if (!UUID_RE.test(id)) return err('Invalid id')

  const sb = admin()
  const { data: cur } = await sb.from('messages').select('image_paths').eq('id', id).maybeSingle()
  if (!cur) return err('Not found', 404)

  const paths = (cur.image_paths ?? []) as string[]
  if (paths.length) await sb.storage.from(BUCKET).remove(paths)

  const { error } = await sb.from('messages').delete().eq('id', id)
  if (error) return err('Server error', 500)
  return json({ ok: true })
}
