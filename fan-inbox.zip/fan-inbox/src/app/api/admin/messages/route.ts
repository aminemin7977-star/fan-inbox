import { isAdmin } from '@/lib/auth'
import { admin } from '@/lib/supabase-admin'
import { SELECT, toAdminMessages, type Row } from '@/lib/messages'
import { err, json } from '@/lib/http'

export const dynamic = 'force-dynamic'

/** Inbox: latest 200 messages (filtering happens in the UI). */
export async function GET() {
  if (!(await isAdmin())) return err('Unauthorized', 401)

  const { data, error } = await admin()
    .from('messages')
    .select(SELECT)
    .order('created_at', { ascending: false })
    .limit(200)

  if (error) return err('Server error', 500)
  return json({ messages: await toAdminMessages((data ?? []) as unknown as Row[]) })
}
