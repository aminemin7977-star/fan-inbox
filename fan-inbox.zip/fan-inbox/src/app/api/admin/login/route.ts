import { checkPassword, COOKIE, createSessionValue, SESSION_TTL } from '@/lib/auth'
import { clientIp, err, json, rateLimit } from '@/lib/http'

export const dynamic = 'force-dynamic'

export async function POST(req: Request) {
  if (!rateLimit(`login:${clientIp(req)}`, 8, 15 * 60_000)) {
    return err('Too many attempts. Try again in a few minutes.', 429)
  }

  const b = (await req.json().catch(() => null)) as { password?: unknown } | null
  if (!b || typeof b.password !== 'string' || !checkPassword(b.password)) {
    return err('Wrong password.', 401)
  }

  const res = json({ ok: true })
  res.cookies.set(COOKIE, createSessionValue(), {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: SESSION_TTL,
  })
  return res
}
