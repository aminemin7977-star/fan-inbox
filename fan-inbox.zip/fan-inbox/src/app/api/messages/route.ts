import { admin } from '@/lib/supabase-admin'
import { MAX_BODY_CHARS, MAX_IMAGES, MAX_NICK_CHARS } from '@/lib/constants'
import { clientIp, err, json, rateLimit } from '@/lib/http'

export const dynamic = 'force-dynamic'

const PATH_RE = /^uploads\/[0-9a-f-]{36}\.(jpg|png|webp|gif|heic)$/

/** Fan submits a message. Returns the secret tracking token. */
export async function POST(req: Request) {
  if (!rateLimit(`msg:${clientIp(req)}`, 10, 10 * 60_000)) {
    return err('Too many messages — please try again in a few minutes.', 429)
  }

  const b = (await req.json().catch(() => null)) as {
    nickname?: unknown
    body?: unknown
    imagePaths?: unknown
    website?: unknown
  } | null
  if (!b) return err('Invalid request.')

  // Honeypot: real people never fill this hidden field.
  if (typeof b.website === 'string' && b.website.trim()) {
    return json({ token: '0'.repeat(64) })
  }

  const body = typeof b.body === 'string' ? b.body.trim() : ''
  const nickname =
    (typeof b.nickname === 'string' ? b.nickname.trim() : '').slice(0, MAX_NICK_CHARS) || 'Anonymous'
  const paths = Array.isArray(b.imagePaths) ? b.imagePaths : []

  if (body.length > MAX_BODY_CHARS) return err(`Message is too long (max ${MAX_BODY_CHARS} characters).`)
  if (paths.length > MAX_IMAGES || !paths.every((p) => typeof p === 'string' && PATH_RE.test(p))) {
    return err('Invalid images.')
  }
  if (!body && paths.length === 0) return err('Write a message or attach an image.')

  const { data, error } = await admin()
    .from('messages')
    .insert({ nickname, body, image_paths: paths })
    .select('tracking_token')
    .single()

  if (error || !data) return err('Could not send your message. Please try again.', 500)
  return json({ token: data.tracking_token as string }, 201)
}
