import { admin } from '@/lib/supabase-admin'
import { SELECT, toAdminMessages, type Row } from '@/lib/messages'
import { err, json, TOKEN_RE } from '@/lib/http'
import type { FanThread } from '@/lib/types'

export const dynamic = 'force-dynamic'

/** A fan loads ONLY the thread that matches their secret token. */
export async function GET(_req: Request, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params
  if (!TOKEN_RE.test(token)) return err('Not found', 404)

  const { data, error } = await admin()
    .from('messages')
    .select(SELECT)
    .eq('tracking_token', token)
    .maybeSingle()

  if (error) return err('Server error', 500)
  if (!data) return err('Not found', 404)

  const [m] = await toAdminMessages([data as unknown as Row])
  // Explicit pick: never expose internal ids or admin-only fields to fans.
  const thread: FanThread = {
    nickname: m.nickname,
    body: m.body,
    status: m.status,
    created_at: m.created_at,
    read_at: m.read_at,
    replied_at: m.replied_at,
    images: m.images,
    replies: m.replies,
  }
  return json(thread)
}
