import { randomUUID } from 'node:crypto'
import { admin } from '@/lib/supabase-admin'
import { BUCKET, IMAGE_EXT, MAX_IMAGES } from '@/lib/constants'
import { clientIp, err, json, rateLimit } from '@/lib/http'

export const dynamic = 'force-dynamic'

/** Mint one-time signed upload URLs so images go straight to Supabase Storage. */
export async function POST(req: Request) {
  if (!rateLimit(`upload:${clientIp(req)}`, 30, 10 * 60_000)) {
    return err('Too many uploads — please wait a few minutes.', 429)
  }

  const body = (await req.json().catch(() => null)) as { types?: unknown } | null
  const types = body?.types
  if (!Array.isArray(types) || types.length < 1 || types.length > MAX_IMAGES) {
    return err(`Attach between 1 and ${MAX_IMAGES} images.`)
  }
  if (!types.every((t) => typeof t === 'string' && t in IMAGE_EXT)) {
    return err('Only JPG, PNG, WebP, GIF or HEIC images are supported.')
  }

  const storage = admin().storage.from(BUCKET)
  const uploads: { path: string; token: string }[] = []
  for (const t of types as string[]) {
    const path = `uploads/${randomUUID()}.${IMAGE_EXT[t]}`
    const { data, error } = await storage.createSignedUploadUrl(path)
    if (error || !data) return err('Could not prepare the upload.', 500)
    uploads.push({ path: data.path, token: data.token })
  }
  return json({ uploads })
}
